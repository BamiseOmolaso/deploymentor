"""
Utility functions for DeployMentor.
"""
