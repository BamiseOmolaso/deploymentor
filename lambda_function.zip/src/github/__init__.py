"""
GitHub API client modules.
"""
